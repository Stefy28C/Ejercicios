package Arrays;

public class DatosClases {


    //variables de ejercicio1

    public int[] A ;
    public int[]B;
    public int[]C;
    public int tam;

    //Variables ejercicio 2
    public int tamano;
    public int mayor;
    public int []Array;

// Variables ejercicio 3
    public int t;
    public int Numero[];
    public int SumaNegativos=0;
    public int SumaPositivos=0;
    public int CPositivos=0;
    public int CNegativos=0;
    public int CCeros=0;

    //Variables ejercicio 4
    public int Arreglo[];
    public int BNumero;

}
